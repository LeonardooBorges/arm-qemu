General steps:

prepare the exception vector table
initialize the hardware, VIC and UART in this case.
implement the interrupt handler