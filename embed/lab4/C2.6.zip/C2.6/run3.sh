#!/bin/bash

gdb-multiarch
