#!/bin/bash

telnet localhost 1122
