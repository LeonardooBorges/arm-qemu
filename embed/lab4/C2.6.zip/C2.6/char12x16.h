#ifndef CHAR_12X16_H
#define CHAR_12X16_H

#include "types.h"

void dchar12x16(u8 c, u32 x, u32 y);
void undchar12x16(u8 c, u32 x, u32 y);
void InitializeFontContext12x16();

#endif